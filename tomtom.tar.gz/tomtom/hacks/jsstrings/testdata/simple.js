var dbl = "bar";
var single = 'foo';
var concat = 'foo' + 'bar';
// comment 'with string'
// in "it"
// and `templates`
var template = `foo bar`;
var doubleWithEscaped = "hello \" there \\";
/*
 * comment block
 * with 'single' and "double" and `template`
 * */
var singleWithEscaped = 'hello \' there \\';
var templateWithEscaped = `hello \` there \\`;
var dev = 123 / 234;
var regex = /foo?['"]\/bar/;
var regexes = [/foo?['"]\/bar/, "must be in output"];
var another = 'another string';

