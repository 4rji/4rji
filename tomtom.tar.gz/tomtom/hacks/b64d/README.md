# b64d

Find and decode base64-encoded strings in a file.

## Usage

```
▶ b64d <filename>
```

## Install

```
▶ go get -u github.com/tomnomnom/hacks/b64d
```
